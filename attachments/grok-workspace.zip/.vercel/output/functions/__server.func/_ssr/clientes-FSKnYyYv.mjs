import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Search, d as ChevronRight, s as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { M as useWorkshop, i as EmptyState, o as PageHead, v as isOpen } from "./router-DSHCkyC1.mjs";
import { i as Input, n as Button } from "./ui-BC_-lu7f.mjs";
import { n as ClientForm, t as AppDrawer } from "./drawers-EBgveiPD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/clientes-FSKnYyYv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClientesPage() {
	const clients = useWorkshop((s) => s.clients);
	const orders = useWorkshop((s) => s.orders);
	const addClient = useWorkshop((s) => s.addClient);
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const list = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return clients.filter((c) => {
			if (!query) return true;
			return `${c.name} ${c.city} ${c.phone}`.toLowerCase().includes(query);
		}).slice().sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
	}, [clients, q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Cadastro",
			title: "Clientes",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				className: "gap-1.5 pl-3 pr-3.5",
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Novo"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Buscar por nome, cidade ou telefone",
					className: "pl-10"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 px-5",
			children: list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Sem clientes",
				hint: "Cadastre lojas e clientes particulares para vincular aos pedidos.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setOpen(true),
					children: "Novo cliente"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl bg-raised shadow-[var(--shadow-card)]",
				children: list.map((c, i) => {
					const openOrders = orders.filter((o) => o.clientId === c.id && isOpen(o.stage)).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/clientes/$id",
						params: { id: c.id },
						className: `flex items-center gap-3 px-4 py-3.5 ${i > 0 ? "border-t border-line" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-wash font-display text-lg italic text-denim",
								children: c.name.charAt(0).toUpperCase()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-[13px] text-muted",
									children: [c.city || "Sem cidade", openOrders > 0 ? ` · ${openOrders} em andamento` : ""]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-subtle" })
						]
					}, c.id);
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppDrawer, {
			open,
			onOpenChange: setOpen,
			title: "Novo cliente",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientForm, {
				submitLabel: "Salvar cliente",
				onSubmit: (v) => {
					addClient(v);
					setOpen(false);
					toast.success("Cliente cadastrado.");
				}
			})
		})
	] });
}
//#endregion
export { ClientesPage as component };
