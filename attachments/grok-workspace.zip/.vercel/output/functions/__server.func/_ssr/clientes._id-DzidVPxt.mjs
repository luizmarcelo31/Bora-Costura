import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as MessageCircle, p as ArrowLeft, s as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { M as useWorkshop, N as whatsappHref, r as Route$2, v as isOpen } from "./router-DSHCkyC1.mjs";
import { n as Button } from "./ui-BC_-lu7f.mjs";
import { n as ClientForm, t as AppDrawer } from "./drawers-EBgveiPD.mjs";
import { t as OrderCard } from "./order-card-BNtwp81-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/clientes._id-DzidVPxt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClienteDetail() {
	const { id } = Route$2.useParams();
	const navigate = useNavigate();
	const client = useWorkshop((s) => s.clients.find((c) => c.id === id));
	const orders = useWorkshop((s) => s.orders.filter((o) => o.clientId === id));
	const payments = useWorkshop((s) => s.payments);
	const updateClient = useWorkshop((s) => s.updateClient);
	const deleteClient = useWorkshop((s) => s.deleteClient);
	const [edit, setEdit] = (0, import_react.useState)(false);
	if (!client) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "px-5 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl italic",
			children: "Cliente não encontrado"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/clientes",
			className: "mt-4 inline-block text-sm text-denim",
			children: "Voltar"
		})]
	});
	const open = orders.filter((o) => isOpen(o.stage));
	const done = orders.filter((o) => !isOpen(o.stage));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 px-3 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/clientes",
					className: "flex size-11 items-center justify-center rounded-md hover:bg-wash",
					"aria-label": "Voltar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] font-medium uppercase tracking-[0.12em] text-muted",
						children: "Cliente"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-[1.75rem] leading-tight italic",
						children: client.name
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-4 px-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-raised p-4 shadow-[var(--shadow-card)]",
					children: [
						client.city ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: client.city
						}) : null,
						client.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm tabular-nums text-ink",
							children: formatPhone(client.phone)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Sem telefone"
						}),
						client.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-ink",
							children: client.notes
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [client.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappHref(client.phone),
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex h-11 items-center gap-2 rounded-md bg-sage px-4 text-sm font-medium text-denim-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), "WhatsApp"]
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => setEdit(true),
								children: "Editar"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Pedidos abertos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/pedidos/novo",
						className: "flex h-9 items-center gap-1 text-[13px] font-medium text-denim",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Novo"]
					})]
				}), open.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-5 text-sm text-muted",
					children: "Nenhum pedido em andamento."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2 px-5",
					children: open.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
						order,
						clientName: client.name,
						payments
					}, order.id))
				})]
			}),
			done.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 px-5 text-sm font-semibold",
					children: "Histórico"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2 px-5",
					children: done.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
						order,
						clientName: client.name,
						payments
					}, order.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-8 px-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "w-full text-brick",
					onClick: () => {
						if (!deleteClient(client.id)) {
							toast.error("Há pedidos vinculados. Exclua ou reatribua antes.");
							return;
						}
						toast.success("Cliente excluído.");
						navigate({ to: "/clientes" });
					},
					children: "Excluir cliente"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppDrawer, {
				open: edit,
				onOpenChange: setEdit,
				title: "Editar cliente",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientForm, {
					initial: client,
					submitLabel: "Salvar alterações",
					onSubmit: (v) => {
						updateClient(client.id, v);
						setEdit(false);
						toast.success("Cliente atualizado.");
					}
				})
			})
		]
	});
}
function formatPhone(raw) {
	const d = raw.replace(/\D/g, "");
	if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
	if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
	return raw;
}
//#endregion
export { ClienteDetail as component };
