import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { M as useWorkshop, c as PAYMENT_METHODS, k as todayIso, s as METHOD_LABEL } from "./router-DSHCkyC1.mjs";
import { a as Select, i as Input, n as Button, o as Textarea, r as Field } from "./ui-BC_-lu7f.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/drawers-EBgveiPD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppDrawer({ open, onOpenChange, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-40 bg-ink/35" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
			className: "fixed inset-x-0 bottom-0 z-50 flex max-h-[92dvh] flex-col rounded-t-xl bg-bg outline-none",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
					className: "px-5 pt-4 font-display text-2xl italic",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-y-auto px-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] pt-4",
					children
				})
			]
		})] })
	});
}
function ClientForm({ initial, submitLabel, onSubmit }) {
	const [name, setName] = (0, import_react.useState)(initial?.name ?? "");
	const [phone, setPhone] = (0, import_react.useState)(initial?.phone ?? "");
	const [city, setCity] = (0, import_react.useState)(initial?.city ?? "");
	const [notes, setNotes] = (0, import_react.useState)(initial?.notes ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-col gap-3",
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) {
				toast.error("Informe o nome do cliente.");
				return;
			}
			onSubmit({
				name: name.trim(),
				phone: phone.trim(),
				city: city.trim(),
				notes: notes.trim()
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nome",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					onChange: (e) => setName(e.target.value),
					placeholder: "Nome ou loja",
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "WhatsApp",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: phone,
					onChange: (e) => setPhone(e.target.value),
					placeholder: "11 99999-0000",
					inputMode: "tel"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Cidade",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: city,
					onChange: (e) => setCity(e.target.value),
					placeholder: "São Paulo"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Observações",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: notes,
					onChange: (e) => setNotes(e.target.value),
					placeholder: "Preferências, retirada, grade…"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "mt-2 w-full",
				children: submitLabel
			})
		]
	});
}
function PaymentForm({ orderId, remaining, onDone }) {
	const addPayment = useWorkshop((s) => s.addPayment);
	const [amount, setAmount] = (0, import_react.useState)(remaining > 0 ? remaining.toFixed(2) : "");
	const [method, setMethod] = (0, import_react.useState)("pix");
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-col gap-3",
		onSubmit: (e) => {
			e.preventDefault();
			const value = Number(String(amount).replace(",", "."));
			if (!Number.isFinite(value) || value <= 0) {
				toast.error("Informe um valor válido.");
				return;
			}
			addPayment({
				orderId,
				amount: value,
				method,
				date,
				note: note.trim()
			});
			toast.success("Pagamento registrado.");
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Valor (R$)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					inputMode: "decimal",
					value: amount,
					onChange: (e) => setAmount(e.target.value),
					className: "tabular-nums"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Forma",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: method,
						onChange: (e) => setMethod(e.target.value),
						children: PAYMENT_METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: m,
							children: METHOD_LABEL[m]
						}, m))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Data",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nota (opcional)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: note,
					onChange: (e) => setNote(e.target.value),
					placeholder: "Sinal, restante…"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "mt-2 w-full",
				children: "Registrar recebimento"
			})
		]
	});
}
//#endregion
export { ClientForm as n, PaymentForm as r, AppDrawer as t };
