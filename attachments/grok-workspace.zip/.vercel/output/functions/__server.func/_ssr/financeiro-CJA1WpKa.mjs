import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { E as payStatus, M as useWorkshop, O as remainingOf, S as money, T as paidOf, h as formatDay, i as EmptyState, m as cn, o as PageHead, p as clientById, s as METHOD_LABEL, v as isOpen, w as orderTotal } from "./router-DSHCkyC1.mjs";
import { n as Button } from "./ui-BC_-lu7f.mjs";
import { r as PaymentForm, t as AppDrawer } from "./drawers-EBgveiPD.mjs";
import { t as PayBadge } from "./stage-badge-DYMbC0JW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/financeiro-CJA1WpKa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FinanceiroPage() {
	const orders = useWorkshop((s) => s.orders);
	const clients = useWorkshop((s) => s.clients);
	const payments = useWorkshop((s) => s.payments);
	const [payFor, setPayFor] = (0, import_react.useState)(null);
	const receivable = (0, import_react.useMemo)(() => orders.filter((o) => remainingOf(o, payments) > 0 && o.stage !== "cancelado").slice().sort((a, b) => remainingOf(b, payments) - remainingOf(a, payments)), [orders, payments]);
	const received = (0, import_react.useMemo)(() => payments.slice().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 12), [payments]);
	const openTotal = receivable.reduce((s, o) => s + remainingOf(o, payments), 0);
	const monthPaid = payments.reduce((s, p) => s + p.amount, 0);
	const billedOpen = orders.filter((o) => isOpen(o.stage)).reduce((s, o) => s + orderTotal(o), 0);
	const paying = orders.find((o) => o.id === payFor);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Recebimentos",
				title: "Caixa"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-2.5 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-raised px-3.5 py-3 shadow-[var(--shadow-card)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.12em] text-muted",
						children: "A receber"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-2xl italic tabular-nums text-brick",
						children: money(openTotal)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-raised px-3.5 py-3 shadow-[var(--shadow-card)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.12em] text-muted",
						children: "Já recebido"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-2xl italic tabular-nums text-sage",
						children: money(monthPaid)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 px-5 text-[12px] text-muted",
				children: [
					money(billedOpen),
					" em pedidos abertos · ",
					receivable.length,
					" conta",
					receivable.length === 1 ? "" : "s",
					" em aberto"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 px-5 text-sm font-semibold",
					children: "Contas em aberto"
				}), receivable.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "Nada em aberto",
					hint: "Quando um pedido tiver saldo, ele aparece aqui para receber."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-5 overflow-hidden rounded-xl bg-raised shadow-[var(--shadow-card)]",
					children: receivable.map((order, i) => {
						const remaining = remainingOf(order, payments);
						const client = clientById(clients, order.clientId);
						const pay = payStatus(order, payments);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("px-4 py-3", i > 0 && "border-t border-line"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/pedidos/$id",
									params: { id: order.id },
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: client?.name ?? "Cliente"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[12px] text-muted tabular-nums",
										children: [
											order.number,
											" · recebido ",
											money(paidOf(payments, order.id))
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold tabular-nums text-brick",
										children: money(remaining)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayBadge, { status: pay })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "mt-2 w-full",
								onClick: () => setPayFor(order.id),
								children: "Registrar recebimento"
							})]
						}, order.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 px-5 text-sm font-semibold",
					children: "Últimos recebimentos"
				}), received.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-5 text-sm text-muted",
					children: "Nenhum pagamento registrado."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-5 overflow-hidden rounded-xl bg-raised shadow-[var(--shadow-card)]",
					children: received.map((p, i) => {
						const order = orders.find((o) => o.id === p.orderId);
						const client = order ? clientById(clients, order.clientId) : void 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("flex items-center justify-between gap-3 px-4 py-3", i > 0 && "border-t border-line"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: client?.name ?? "Pedido"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[12px] text-muted",
									children: [
										METHOD_LABEL[p.method],
										" · ",
										formatDay(p.date),
										order ? ` · ${order.number}` : ""
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "shrink-0 text-sm font-semibold tabular-nums text-sage",
								children: money(p.amount)
							})]
						}, p.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppDrawer, {
				open: Boolean(paying),
				onOpenChange: (v) => !v && setPayFor(null),
				title: "Recebimento",
				children: paying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentForm, {
					orderId: paying.id,
					remaining: remainingOf(paying, payments),
					onDone: () => setPayFor(null)
				}) : null
			})
		]
	});
}
//#endregion
export { FinanceiroPage as component };
