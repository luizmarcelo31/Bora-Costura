import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as ChevronRight } from "../_libs/lucide-react.mjs";
import { D as prazoLabel, E as payStatus, O as remainingOf, S as money, h as formatDay, m as cn, w as orderTotal, x as itemSummary, y as isOverdue } from "./router-DSHCkyC1.mjs";
import { n as StageBadge } from "./stage-badge-DYMbC0JW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-card-BNtwp81-.js
var import_jsx_runtime = require_jsx_runtime();
function OrderCard({ order, clientName, payments }) {
	const overdue = isOverdue(order);
	const remaining = remainingOf(order, payments);
	const pay = payStatus(order, payments);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/pedidos/$id",
		params: { id: order.id },
		className: cn("flex items-stretch gap-0 rounded-lg bg-raised shadow-[var(--shadow-card)] transition-[transform,box-shadow] duration-150 active:scale-[0.99]", overdue && "shadow-[0_0_0_1px_var(--color-brick),0_8px_20px_rgb(27_29_36/0.04)]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("w-1 shrink-0 rounded-l-lg", overdue ? "bg-brick" : order.stage === "pronto" ? "bg-sage" : "bg-denim/70"),
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 items-center gap-3 px-3.5 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-ink tabular-nums",
							children: order.number
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StageBadge, { stage: order.stage })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 truncate text-sm text-ink",
						children: clientName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-[13px] text-muted",
						children: itemSummary(order.items)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("tabular-nums", overdue && "font-semibold text-brick"),
							children: [
								prazoLabel(order),
								" · ",
								formatDay(order.dueDate)
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: pay === "pago" ? money(orderTotal(order)) : `${money(remaining)} em aberto`
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 shrink-0 text-subtle" })]
		})]
	});
}
//#endregion
export { OrderCard as t };
