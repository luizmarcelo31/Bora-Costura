import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Search, s as Plus } from "../_libs/lucide-react.mjs";
import { M as useWorkshop, i as EmptyState, m as cn, o as PageHead, p as clientById, v as isOpen, x as itemSummary, y as isOverdue } from "./router-DSHCkyC1.mjs";
import { i as Input, n as Button } from "./ui-BC_-lu7f.mjs";
import { t as OrderCard } from "./order-card-BNtwp81-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pedidos-DXoeFVSi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "abertos",
		label: "Abertos"
	},
	{
		id: "atraso",
		label: "Atraso"
	},
	{
		id: "pronto",
		label: "Prontos"
	},
	{
		id: "todos",
		label: "Todos"
	}
];
function PedidosPage() {
	const orders = useWorkshop((s) => s.orders);
	const clients = useWorkshop((s) => s.clients);
	const payments = useWorkshop((s) => s.payments);
	const [q, setQ] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("abertos");
	const list = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return orders.filter((o) => {
			if (filter === "abertos") return isOpen(o.stage);
			if (filter === "atraso") return isOverdue(o);
			if (filter === "pronto") return o.stage === "pronto";
			return true;
		}).filter((o) => {
			if (!query) return true;
			const client = clientById(clients, o.clientId);
			return `${o.number} ${client?.name ?? ""} ${itemSummary(o.items)}`.toLowerCase().includes(query);
		}).slice().sort((a, b) => a.dueDate.localeCompare(b.dueDate));
	}, [
		orders,
		clients,
		q,
		filter
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Carteira",
			title: "Pedidos",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/pedidos/novo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					className: "gap-1.5 pl-3 pr-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Novo"]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Buscar cliente, peça ou número",
					className: "pl-10"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1.5 overflow-x-auto pb-1",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(f.id),
					className: cn("h-9 shrink-0 rounded-full px-3.5 text-[13px] font-medium transition-colors duration-150", filter === f.id ? "bg-denim text-denim-fg" : "bg-wash text-muted"),
					children: f.label
				}, f.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 flex flex-col gap-2 px-5",
			children: list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Nada por aqui",
				hint: q ? "Tente outro termo de busca." : "Crie o primeiro pedido da oficina.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/pedidos/novo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Novo pedido" })
				})
			}) : list.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
				order,
				clientName: clientById(clients, order.clientId)?.name ?? "Cliente",
				payments
			}, order.id))
		})
	] });
}
//#endregion
export { PedidosPage as component };
