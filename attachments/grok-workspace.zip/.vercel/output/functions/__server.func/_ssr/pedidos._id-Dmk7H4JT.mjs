import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as MessageCircle, i as Trash2, p as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as nextStage, D as prazoLabel, E as payStatus, M as useWorkshop, N as whatsappHref, O as remainingOf, P as whatsappOrderText, S as money, T as paidOf, b as itemCount, d as STAGE_HINT, f as STAGE_LABEL, g as formatDayLong, m as cn, n as Route$1, p as clientById, s as METHOD_LABEL, u as STAGES, v as isOpen, w as orderTotal, y as isOverdue } from "./router-DSHCkyC1.mjs";
import { n as Button } from "./ui-BC_-lu7f.mjs";
import { r as PaymentForm, t as AppDrawer } from "./drawers-EBgveiPD.mjs";
import { n as StageBadge, t as PayBadge } from "./stage-badge-DYMbC0JW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pedidos._id-Dmk7H4JT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PedidoDetail() {
	const { id } = Route$1.useParams();
	const navigate = useNavigate();
	const order = useWorkshop((s) => s.orders.find((o) => o.id === id));
	const clients = useWorkshop((s) => s.clients);
	const payments = useWorkshop((s) => s.payments);
	const setStage = useWorkshop((s) => s.setStage);
	const advance = useWorkshop((s) => s.advance);
	const deleteOrder = useWorkshop((s) => s.deleteOrder);
	const deletePayment = useWorkshop((s) => s.deletePayment);
	const [payOpen, setPayOpen] = (0, import_react.useState)(false);
	if (!order) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "px-5 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl italic",
			children: "Pedido não encontrado"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/pedidos",
			className: "mt-4 inline-block text-sm text-denim",
			children: "Voltar aos pedidos"
		})]
	});
	const client = clientById(clients, order.clientId);
	const total = orderTotal(order);
	const paid = paidOf(payments, order.id);
	const remaining = remainingOf(order, payments);
	const pay = payStatus(order, payments);
	const nxt = nextStage(order.stage);
	const overdue = isOverdue(order);
	const orderPayments = payments.filter((p) => p.orderId === order.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 px-3 pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pedidos",
						className: "flex size-11 items-center justify-center rounded-md text-ink hover:bg-wash",
						"aria-label": "Voltar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] font-medium uppercase tracking-[0.12em] text-muted",
							children: "Pedido"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-2xl italic leading-none tabular-nums",
							children: order.number
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StageBadge, { stage: order.stage })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-5 px-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-raised p-4 shadow-[var(--shadow-card)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] font-medium uppercase tracking-[0.12em] text-muted",
							children: "Cliente"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/clientes/$id",
							params: { id: order.clientId },
							className: "mt-1 block font-medium text-ink",
							children: client?.name ?? "Cliente removido"
						}),
						client?.city ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: client.city
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("mt-3 text-sm", overdue ? "font-semibold text-brick" : "text-muted"),
							children: [
								"Prazo ",
								formatDayLong(order.dueDate),
								" · ",
								prazoLabel(order)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: STAGE_HINT[order.stage]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Total",
							value: money(total)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Recebido",
							value: money(paid)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Aberto",
							value: money(remaining),
							tone: remaining > 0 ? "brick" : "sage"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayBadge, { status: pay })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mb-2 text-sm font-semibold",
					children: ["Peças · ", itemCount(order)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "overflow-hidden rounded-lg bg-raised shadow-[var(--shadow-card)]",
					children: order.items.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("flex items-start justify-between gap-3 px-4 py-3", i > 0 && "border-t border-line"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-medium",
								children: [
									item.quantity,
									"× ",
									item.description
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[13px] text-muted",
								children: [
									item.fabric,
									item.color,
									item.size
								].filter(Boolean).join(" · ")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "shrink-0 text-sm tabular-nums",
							children: money(item.quantity * item.unitPrice)
						})]
					}, item.id))
				})]
			}),
			order.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-sm font-semibold",
					children: "Observações"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg bg-raised px-4 py-3 text-sm text-ink shadow-[var(--shadow-card)]",
					children: order.notes
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 text-sm font-semibold",
						children: "Produção"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1.5 overflow-x-auto pb-1",
						children: STAGES.map((s) => {
							const active = order.stage === s;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setStage(order.id, s);
									toast.message(`Etapa: ${STAGE_LABEL[s]}`);
								},
								className: cn("h-9 shrink-0 rounded-full px-3 text-[12px] font-medium", active ? "bg-denim text-denim-fg" : "bg-wash text-muted"),
								children: STAGE_LABEL[s]
							}, s);
						})
					}),
					nxt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3 w-full",
						variant: order.stage === "pronto" ? "sage" : "primary",
						onClick: () => {
							const next = advance(order.id);
							if (next) toast.success(`Avançou para ${STAGE_LABEL[next].toLowerCase()}`);
						},
						children: order.stage === "pronto" ? "Marcar como entregue" : `Avançar para ${STAGE_LABEL[nxt].toLowerCase()}`
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Recebimentos"
					}), remaining > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-9 text-[13px] font-medium text-denim",
						onClick: () => setPayOpen(true),
						children: "Registrar"
					}) : null]
				}), orderPayments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Nenhum pagamento ainda."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "overflow-hidden rounded-lg bg-raised shadow-[var(--shadow-card)]",
					children: orderPayments.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("flex items-center gap-3 px-4 py-3", i > 0 && "border-t border-line"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium tabular-nums",
								children: money(p.amount)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[12px] text-muted",
								children: [
									METHOD_LABEL[p.method],
									" · ",
									formatDayLong(p.date),
									p.note ? ` · ${p.note}` : ""
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-9 items-center justify-center text-subtle hover:text-brick",
							onClick: () => deletePayment(p.id),
							"aria-label": "Excluir pagamento",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					}, p.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 flex flex-col gap-2 px-5",
				children: [
					client?.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: whatsappHref(client.phone, whatsappOrderText(client, order)),
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex h-11 items-center justify-center gap-2 rounded-md bg-sage text-sm font-medium text-denim-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), "WhatsApp do cliente"]
					}) : null,
					isOpen(order.stage) && remaining > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => setPayOpen(true),
						children: "Registrar pagamento"
					}) : null,
					order.stage !== "cancelado" && isOpen(order.stage) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => {
							setStage(order.id, "cancelado");
							toast.message("Pedido cancelado.");
						},
						children: "Cancelar pedido"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "text-brick",
						onClick: () => {
							if (!confirm("Excluir este pedido e os pagamentos vinculados?")) return;
							deleteOrder(order.id);
							toast.success("Pedido excluído.");
							navigate({ to: "/pedidos" });
						},
						children: "Excluir pedido"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppDrawer, {
				open: payOpen,
				onOpenChange: setPayOpen,
				title: "Recebimento",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentForm, {
					orderId: order.id,
					remaining,
					onDone: () => setPayOpen(false)
				})
			})
		]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-raised px-3 py-2.5 shadow-[var(--shadow-card)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-medium uppercase tracking-[0.12em] text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-0.5 text-sm font-semibold tabular-nums", tone === "brick" ? "text-brick" : tone === "sage" ? "text-sage" : "text-ink"),
			children: value
		})]
	});
}
//#endregion
export { PedidoDetail as component };
