import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Trash2, s as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { M as useWorkshop, S as money, f as STAGE_LABEL, j as uid, k as todayIso, l as SIZE_OPTIONS, o as PageHead, u as STAGES, w as orderTotal } from "./router-DSHCkyC1.mjs";
import { a as Select, i as Input, n as Button, o as Textarea, r as Field } from "./ui-BC_-lu7f.mjs";
import { n as ClientForm, t as AppDrawer } from "./drawers-EBgveiPD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pedidos.novo-DAwR8ALt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function emptyItem() {
	return {
		id: uid("i"),
		description: "",
		fabric: "",
		color: "",
		size: "M",
		quantity: 1,
		unitPrice: 0
	};
}
function NovoPedido() {
	const navigate = useNavigate();
	const clients = useWorkshop((s) => s.clients);
	const addOrder = useWorkshop((s) => s.addOrder);
	const addClient = useWorkshop((s) => s.addClient);
	const [clientId, setClientId] = (0, import_react.useState)(clients[0]?.id ?? "");
	const [stage, setStage] = (0, import_react.useState)("aprovado");
	const [dueDate, setDueDate] = (0, import_react.useState)(todayIso());
	const [notes, setNotes] = (0, import_react.useState)("");
	const [items, setItems] = (0, import_react.useState)([emptyItem()]);
	const [clientOpen, setClientOpen] = (0, import_react.useState)(false);
	const total = (0, import_react.useMemo)(() => orderTotal({ items }), [items]);
	function patchItem(id, patch) {
		setItems((list) => list.map((i) => i.id === id ? {
			...i,
			...patch
		} : i));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Novo",
			title: "Pedido"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4 px-5 pb-8",
			onSubmit: (e) => {
				e.preventDefault();
				if (!clientId) {
					toast.error("Selecione um cliente.");
					return;
				}
				const clean = items.filter((i) => i.description.trim() && i.quantity > 0);
				if (clean.length === 0) {
					toast.error("Inclua ao menos uma peça.");
					return;
				}
				const id = addOrder({
					clientId,
					items: clean,
					stage,
					dueDate,
					deliveryDate: dueDate,
					deliveredAt: null,
					notes: notes.trim()
				});
				toast.success("Pedido criado.");
				navigate({
					to: "/pedidos/$id",
					params: { id }
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Cliente",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: clientId,
							onChange: (e) => setClientId(e.target.value),
							className: "flex-1",
							children: [clients.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Nenhum cliente"
							}) : null, clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.id,
								children: c.name
							}, c.id))]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							onClick: () => setClientOpen(true),
							children: "Novo"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Etapa",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: stage,
							onChange: (e) => setStage(e.target.value),
							children: STAGES.filter((s) => s !== "entregue").map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: STAGE_LABEL[s]
							}, s))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Prazo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: dueDate,
							onChange: (e) => setDueDate(e.target.value),
							required: true
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[13px] font-medium text-muted",
							children: "Peças"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex h-9 items-center gap-1 text-[13px] font-medium text-denim",
							onClick: () => setItems((list) => [...list, emptyItem()]),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Adicionar peça"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-3",
						children: items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-raised p-3 shadow-[var(--shadow-card)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[12px] font-medium text-muted",
										children: ["Peça ", idx + 1]
									}), items.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "flex size-9 items-center justify-center text-brick",
										onClick: () => setItems((list) => list.filter((i) => i.id !== item.id)),
										"aria-label": "Remover peça",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Modelo",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: item.description,
										onChange: (e) => patchItem(item.id, { description: e.target.value }),
										placeholder: "Vestido midi, camisa polo…"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Tecido",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: item.fabric,
											onChange: (e) => patchItem(item.id, { fabric: e.target.value }),
											placeholder: "Linho, malha…"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Cor",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: item.color,
											onChange: (e) => patchItem(item.id, { color: e.target.value })
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Tam.",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: item.size,
												onChange: (e) => patchItem(item.id, { size: e.target.value }),
												list: "sizes"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Qtd",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 1,
												value: item.quantity,
												onChange: (e) => patchItem(item.id, { quantity: Math.max(1, Number(e.target.value) || 1) }),
												className: "tabular-nums"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "R$ un.",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												inputMode: "decimal",
												value: item.unitPrice || "",
												onChange: (e) => patchItem(item.id, { unitPrice: Number(e.target.value.replace(",", ".")) || 0 }),
												className: "tabular-nums"
											})
										})
									]
								})
							]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
						id: "sizes",
						children: SIZE_OPTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: s }, s))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Observações",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						placeholder: "Acabamento, prova, retirada…"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between rounded-lg bg-denim px-4 py-3 text-denim-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Total"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl italic tabular-nums",
						children: money(total)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					size: "lg",
					children: "Salvar pedido"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppDrawer, {
			open: clientOpen,
			onOpenChange: setClientOpen,
			title: "Novo cliente",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientForm, {
				submitLabel: "Cadastrar e usar",
				onSubmit: (v) => {
					const id = addClient(v);
					setClientId(id);
					setClientOpen(false);
					toast.success("Cliente cadastrado.");
				}
			})
		})
	] });
}
//#endregion
export { NovoPedido as component };
