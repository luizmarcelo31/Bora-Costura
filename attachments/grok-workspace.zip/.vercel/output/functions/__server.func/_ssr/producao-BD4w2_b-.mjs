import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as nextStage, M as useWorkshop, O as remainingOf, S as money, d as STAGE_HINT, f as STAGE_LABEL, h as formatDay, i as EmptyState, m as cn, o as PageHead, p as clientById, u as STAGES, x as itemSummary, y as isOverdue } from "./router-DSHCkyC1.mjs";
import { n as Button } from "./ui-BC_-lu7f.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/producao-BD4w2_b-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FLOOR = STAGES.filter((s) => s !== "entregue");
function ProducaoPage() {
	const orders = useWorkshop((s) => s.orders);
	const clients = useWorkshop((s) => s.clients);
	const payments = useWorkshop((s) => s.payments);
	const advance = useWorkshop((s) => s.advance);
	const [focus, setFocus] = (0, import_react.useState)("todos");
	const byStage = FLOOR.map((stage) => ({
		stage,
		orders: orders.filter((o) => o.stage === stage).slice().sort((a, b) => a.dueDate.localeCompare(b.dueDate))
	}));
	const visible = focus === "todos" ? byStage : byStage.filter((s) => s.stage === focus);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Chão de fábrica",
			title: "Produção"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-1.5 overflow-x-auto px-5 pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				active: focus === "todos",
				onClick: () => setFocus("todos"),
				label: "Tudo",
				count: orders.filter((o) => FLOOR.includes(o.stage)).length
			}), byStage.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				active: focus === col.stage,
				onClick: () => setFocus(col.stage),
				label: STAGE_LABEL[col.stage],
				count: col.orders.length
			}, col.stage))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("mt-2 gap-3 px-5", focus === "todos" ? "md:grid md:grid-cols-3 lg:grid-cols-6" : "flex flex-col"),
			children: visible.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: STAGE_LABEL[col.stage]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted",
						children: STAGE_HINT[col.stage]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-[12px] text-muted",
						children: col.orders.length
					})]
				}), col.orders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg border border-dashed border-line px-3 py-6 text-center text-[12px] text-subtle",
					children: "Fila vazia"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: col.orders.map((order) => {
						const nxt = nextStage(order.stage);
						const overdue = isOverdue(order);
						const client = clientById(clients, order.clientId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: cn("rounded-lg bg-raised p-3 shadow-[var(--shadow-card)]", overdue && "shadow-[0_0_0_1px_var(--color-brick),0_8px_20px_rgb(27_29_36/0.04)]"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/pedidos/$id",
								params: { id: order.id },
								className: "block",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[12px] font-medium tabular-nums text-muted",
										children: order.number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-medium",
										children: client?.name ?? "Cliente"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-[12px] text-muted",
										children: itemSummary(order.items)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: cn("mt-1 text-[12px] tabular-nums", overdue ? "font-semibold text-brick" : "text-muted"),
										children: [formatDay(order.dueDate), remainingOf(order, payments) > 0 ? ` · ${money(remainingOf(order, payments))} aberto` : ""]
									})
								]
							}), nxt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: order.stage === "pronto" ? "sage" : "secondary",
								className: "mt-2 w-full",
								onClick: () => {
									const next = advance(order.id);
									if (next) toast.success(`${order.number} → ${STAGE_LABEL[next]}`);
								},
								children: order.stage === "pronto" ? "Entregar" : `Ir para ${STAGE_LABEL[nxt].toLowerCase()}`
							}) : null]
						}, order.id);
					})
				})]
			}, col.stage))
		}),
		orders.every((o) => o.stage === "entregue" || o.stage === "cancelado") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Nada na fila",
			hint: "Quando entrar um pedido aprovado, ele aparece aqui."
		}) : null
	] });
}
function Chip({ active, onClick, label, count }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3 text-[13px] font-medium", active ? "bg-denim text-denim-fg" : "bg-wash text-muted"),
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums opacity-80",
			children: count
		})]
	});
}
//#endregion
export { ProducaoPage as component };
