import { i as __toESM } from "../_runtime.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as differenceInCalendarDays, i as isValid, n as parseISO, r as format, t as ptBR } from "../_libs/date-fns.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { l as House, n as Users, o as Scissors, r as TriangleAlert, t as Wallet, u as ClipboardList } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-DXL0m38x.js
function money(value) {
	return new Intl.NumberFormat("pt-BR", {
		style: "currency",
		currency: "BRL"
	}).format(value);
}
function parseDate(iso) {
	if (!iso) return null;
	const d = parseISO(iso);
	return isValid(d) ? d : null;
}
function formatDay(iso) {
	const d = parseDate(iso);
	if (!d) return "—";
	return format(d, "d MMM", { locale: ptBR });
}
function formatDayLong(iso) {
	const d = parseDate(iso);
	if (!d) return "—";
	return format(d, "d 'de' MMMM", { locale: ptBR });
}
function todayIso() {
	return format(/* @__PURE__ */ new Date(), "yyyy-MM-dd");
}
function daysFromToday(iso) {
	const d = parseDate(iso);
	if (!d) return null;
	return differenceInCalendarDays(d, /* @__PURE__ */ new Date());
}
function greeting() {
	const h = (/* @__PURE__ */ new Date()).getHours();
	if (h < 12) return "Bom dia";
	if (h < 18) return "Boa tarde";
	return "Boa noite";
}
function todayLabel() {
	return format(/* @__PURE__ */ new Date(), "EEEE, d 'de' MMMM", { locale: ptBR });
}
function whatsappHref(phone, text) {
	const digits = phone.replace(/\D/g, "");
	const url = `https://wa.me/${digits.startsWith("55") ? digits : `55${digits}`}`;
	return text ? `${url}?text=${encodeURIComponent(text)}` : url;
}
function isoFromNow(days) {
	const d = /* @__PURE__ */ new Date();
	d.setHours(12, 0, 0, 0);
	d.setDate(d.getDate() + days);
	return format(d, "yyyy-MM-dd");
}
function createSeedState() {
	return {
		clients: [
			{
				id: "c1",
				name: "Ana Paula Souza",
				phone: "11987654321",
				city: "São Paulo",
				notes: "Dona da Boutique Flores. Prefere linho e cores terrosas. Retira no ateliê.",
				createdAt: isoFromNow(-40)
			},
			{
				id: "c2",
				name: "Carlos Henrique Lima",
				phone: "11976543210",
				city: "Guarulhos",
				notes: "Uniformes Lima. Pedidos grandes, precisa de grade completa. Paga no Pix após entrega.",
				createdAt: isoFromNow(-55)
			},
			{
				id: "c3",
				name: "Maria Clara Ribeiro",
				phone: "19998761122",
				city: "Campinas",
				notes: "Cliente particular. Gosta de prova antes do acabamento.",
				createdAt: isoFromNow(-18)
			},
			{
				id: "c4",
				name: "Escola Estrelinha",
				phone: "1134567890",
				city: "Osasco",
				notes: "Contato: coordenadora Helena. Uniformes com logo bordado no peito.",
				createdAt: isoFromNow(-12)
			},
			{
				id: "c5",
				name: "Juliana Mendes",
				phone: "21988884455",
				city: "Rio de Janeiro",
				notes: "Loja JM. Envio via malote nas quintas.",
				createdAt: isoFromNow(-70)
			},
			{
				id: "c6",
				name: "Pedro Santos",
				phone: "11912345566",
				city: "São Paulo",
				notes: "Restaurante Barolo. Aventais e camisetas da equipe.",
				createdAt: isoFromNow(-8)
			}
		],
		orders: [
			{
				id: "o1",
				number: "PED-012",
				clientId: "c1",
				stage: "costura",
				dueDate: isoFromNow(2),
				deliveryDate: isoFromNow(2),
				deliveredAt: null,
				notes: "Barra italiana. Fecho invisível nas costas.",
				createdAt: isoFromNow(-9),
				items: [{
					id: "i1a",
					description: "Vestido midi",
					fabric: "Linho misto",
					color: "Areia",
					size: "M",
					quantity: 2,
					unitPrice: 280
				}, {
					id: "i1b",
					description: "Vestido midi",
					fabric: "Linho misto",
					color: "Terracota",
					size: "G",
					quantity: 2,
					unitPrice: 280
				}]
			},
			{
				id: "o2",
				number: "PED-013",
				clientId: "c2",
				stage: "corte",
				dueDate: isoFromNow(5),
				deliveryDate: isoFromNow(6),
				deliveredAt: null,
				notes: "Logo bordado no peito esquerdo. Grade: 4P 8M 8G.",
				createdAt: isoFromNow(-4),
				items: [{
					id: "i2a",
					description: "Camisa polo uniforme",
					fabric: "Piquet",
					color: "Marinho",
					size: "Grade",
					quantity: 20,
					unitPrice: 78
				}]
			},
			{
				id: "o3",
				number: "PED-014",
				clientId: "c3",
				stage: "acabamento",
				dueDate: todayIso(),
				deliveryDate: todayIso(),
				deliveredAt: null,
				notes: "Festa no sábado. Decote V, forro completo. Prova já aprovada.",
				createdAt: isoFromNow(-16),
				items: [{
					id: "i3a",
					description: "Vestido de festa",
					fabric: "Crepe com tule",
					color: "Verde musgo",
					size: "P",
					quantity: 1,
					unitPrice: 890
				}]
			},
			{
				id: "o4",
				number: "PED-015",
				clientId: "c4",
				stage: "aprovado",
				dueDate: isoFromNow(14),
				deliveryDate: isoFromNow(14),
				deliveredAt: null,
				notes: "Aguardar tecido do fornecedor (previsão sexta). Bordado do brasão incluso.",
				createdAt: isoFromNow(-3),
				items: [{
					id: "i4a",
					description: "Conjunto escolar (camiseta + short)",
					fabric: "Malha PV",
					color: "Azul royal",
					size: "Infantil",
					quantity: 40,
					unitPrice: 62
				}]
			},
			{
				id: "o5",
				number: "PED-010",
				clientId: "c5",
				stage: "entregue",
				dueDate: isoFromNow(-8),
				deliveryDate: isoFromNow(-8),
				deliveredAt: isoFromNow(-7),
				notes: "Enviado no malote de quinta.",
				createdAt: isoFromNow(-21),
				items: [{
					id: "i5a",
					description: "Blusa manga bufante",
					fabric: "Viscose",
					color: "Off-white",
					size: "M",
					quantity: 6,
					unitPrice: 95
				}, {
					id: "i5b",
					description: "Blusa manga bufante",
					fabric: "Viscose",
					color: "Preto",
					size: "G",
					quantity: 6,
					unitPrice: 95
				}]
			},
			{
				id: "o6",
				number: "PED-016",
				clientId: "c6",
				stage: "orcamento",
				dueDate: isoFromNow(10),
				deliveryDate: isoFromNow(10),
				deliveredAt: null,
				notes: "Enviar orçamento com e sem bordado do nome do restaurante.",
				createdAt: isoFromNow(-1),
				items: [{
					id: "i6a",
					description: "Avental peitoral",
					fabric: "Brim",
					color: "Preto",
					size: "Único",
					quantity: 8,
					unitPrice: 54
				}]
			},
			{
				id: "o7",
				number: "PED-011",
				clientId: "c1",
				stage: "pronto",
				dueDate: isoFromNow(-1),
				deliveryDate: todayIso(),
				deliveredAt: null,
				notes: "Aguardando retirada. Já avisada no WhatsApp ontem.",
				createdAt: isoFromNow(-14),
				items: [{
					id: "i7a",
					description: "Saia envelope",
					fabric: "Alfaiataria",
					color: "Caramelo",
					size: "M",
					quantity: 3,
					unitPrice: 160
				}, {
					id: "i7b",
					description: "Saia envelope",
					fabric: "Alfaiataria",
					color: "Caramelo",
					size: "G",
					quantity: 3,
					unitPrice: 160
				}]
			},
			{
				id: "o8",
				number: "PED-009",
				clientId: "c2",
				stage: "costura",
				dueDate: isoFromNow(-4),
				deliveryDate: isoFromNow(-2),
				deliveredAt: null,
				notes: "ATRASADO. Faltou linha da cor — chegou hoje. Prioridade na máquina 2.",
				createdAt: isoFromNow(-18),
				items: [{
					id: "i8a",
					description: "Calça social uniforme",
					fabric: "Twill",
					color: "Chumbo",
					size: "Grade",
					quantity: 15,
					unitPrice: 110
				}]
			}
		],
		payments: [
			{
				id: "p1",
				orderId: "o1",
				amount: 560,
				date: isoFromNow(-8),
				method: "pix",
				note: "Sinal 50%"
			},
			{
				id: "p2",
				orderId: "o3",
				amount: 890,
				date: isoFromNow(-10),
				method: "pix",
				note: "Pagamento integral na aprovação"
			},
			{
				id: "p3",
				orderId: "o4",
				amount: 744,
				date: isoFromNow(-2),
				method: "transferencia",
				note: "Sinal 30%"
			},
			{
				id: "p4",
				orderId: "o5",
				amount: 1140,
				date: isoFromNow(-7),
				method: "pix",
				note: "Quitado na entrega"
			},
			{
				id: "p5",
				orderId: "o7",
				amount: 960,
				date: isoFromNow(-3),
				method: "pix",
				note: ""
			},
			{
				id: "p6",
				orderId: "o8",
				amount: 800,
				date: isoFromNow(-15),
				method: "boleto",
				note: "Entrada"
			}
		]
	};
}
var STAGES = [
	"orcamento",
	"aprovado",
	"corte",
	"costura",
	"acabamento",
	"pronto",
	"entregue"
];
var PAYMENT_METHODS = [
	"pix",
	"dinheiro",
	"cartao",
	"boleto",
	"transferencia"
];
var STAGE_LABEL = {
	orcamento: "Orçamento",
	aprovado: "Aprovado",
	corte: "Corte",
	costura: "Costura",
	acabamento: "Acabamento",
	pronto: "Pronto",
	entregue: "Entregue",
	cancelado: "Cancelado"
};
var STAGE_HINT = {
	orcamento: "Aguardando aprovação",
	aprovado: "Liberado para produzir",
	corte: "No risco e corte",
	costura: "Nas máquinas",
	acabamento: "Passadoria e arremate",
	pronto: "Aguardando entrega",
	entregue: "Com o cliente",
	cancelado: "Pedido cancelado"
};
var METHOD_LABEL = {
	pix: "Pix",
	dinheiro: "Dinheiro",
	cartao: "Cartão",
	boleto: "Boleto",
	transferencia: "Transferência"
};
var SIZE_OPTIONS = [
	"PP",
	"P",
	"M",
	"G",
	"GG",
	"XG",
	"Único"
];
function orderTotal(order) {
	return order.items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
}
function itemCount(order) {
	return order.items.reduce((sum, item) => sum + item.quantity, 0);
}
function itemSummary(items) {
	if (items.length === 0) return "Sem peças";
	const first = items[0];
	const qty = items.reduce((s, i) => s + i.quantity, 0);
	if (items.length === 1) return `${first.quantity}× ${first.description}`;
	return `${qty} peças · ${items.length} modelos`;
}
function paidOf(payments, orderId) {
	return payments.filter((p) => p.orderId === orderId).reduce((sum, p) => sum + p.amount, 0);
}
function remainingOf(order, payments) {
	return Math.max(0, round2(orderTotal(order) - paidOf(payments, order.id)));
}
function payStatus(order, payments) {
	const paid = paidOf(payments, order.id);
	const total = orderTotal(order);
	if (total <= 0) return "pago";
	if (paid <= 0) return "pendente";
	if (paid + .009 >= total) return "pago";
	return "parcial";
}
function isOpen(stage) {
	return stage !== "entregue" && stage !== "cancelado";
}
function isOverdue(order) {
	if (!isOpen(order.stage)) return false;
	const days = daysFromToday(order.dueDate);
	return days !== null && days < 0;
}
function nextStage(stage) {
	if (stage === "cancelado") return null;
	const i = STAGES.indexOf(stage);
	if (i < 0 || i >= STAGES.length - 1) return null;
	return STAGES[i + 1];
}
function nextNumber(orders) {
	const max = orders.reduce((acc, o) => {
		const n = Number.parseInt(o.number.replace(/\D/g, ""), 10);
		return Number.isFinite(n) ? Math.max(acc, n) : acc;
	}, 0);
	return `PED-${String(max + 1).padStart(3, "0")}`;
}
function clientById(clients, id) {
	return clients.find((c) => c.id === id);
}
function round2(n) {
	return Math.round(n * 100) / 100;
}
function prazoLabel(order) {
	if (!isOpen(order.stage)) return order.deliveredAt ? "Entregue" : STAGE_LABEL[order.stage];
	const days = daysFromToday(order.dueDate);
	if (days === null) return "Sem prazo";
	if (days === 0) return "Entregar hoje";
	if (days === 1) return "Amanhã";
	if (days === -1) return "1 dia atrasado";
	if (days < 0) return `${Math.abs(days)} dias atrasado`;
	return `${days} dias`;
}
function whatsappOrderText(client, order) {
	const pieces = itemSummary(order.items);
	const stage = STAGE_LABEL[order.stage];
	return `Olá, ${client.name.split(" ")[0]}! Sobre o pedido ${order.number} (${pieces}): está em ${stage.toLowerCase()}. Qualquer dúvida, estamos à disposição.`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${crypto.randomUUID().slice(0, 8)}`;
}
var useWorkshop = create()(persist((set, get) => ({
	...createSeedState(),
	addClient: (input) => {
		const id = uid("c");
		const client = {
			...input,
			id,
			createdAt: todayIso()
		};
		set({ clients: [...get().clients, client] });
		return id;
	},
	updateClient: (id, patch) => {
		set({ clients: get().clients.map((c) => c.id === id ? {
			...c,
			...patch
		} : c) });
	},
	deleteClient: (id) => {
		if (get().orders.some((o) => o.clientId === id)) return false;
		set({ clients: get().clients.filter((c) => c.id !== id) });
		return true;
	},
	addOrder: (input) => {
		const id = uid("o");
		set({ orders: [{
			...input,
			id,
			number: nextNumber(get().orders),
			createdAt: todayIso()
		}, ...get().orders] });
		return id;
	},
	updateOrder: (id, patch) => {
		set({ orders: get().orders.map((o) => o.id === id ? {
			...o,
			...patch
		} : o) });
	},
	deleteOrder: (id) => {
		set({
			orders: get().orders.filter((o) => o.id !== id),
			payments: get().payments.filter((p) => p.orderId !== id)
		});
	},
	setStage: (id, stage) => {
		set({ orders: get().orders.map((o) => {
			if (o.id !== id) return o;
			const deliveredAt = stage === "entregue" ? o.deliveredAt ?? todayIso() : stage === "cancelado" ? o.deliveredAt : null;
			return {
				...o,
				stage,
				deliveredAt
			};
		}) });
	},
	advance: (id) => {
		const order = get().orders.find((o) => o.id === id);
		if (!order) return null;
		const nxt = nextStage(order.stage);
		if (!nxt) return null;
		get().setStage(id, nxt);
		return nxt;
	},
	addPayment: (input) => {
		const payment = {
			...input,
			id: uid("p")
		};
		set({ payments: [...get().payments, payment] });
	},
	deletePayment: (id) => {
		set({ payments: get().payments.filter((p) => p.id !== id) });
	},
	resetDemo: () => set(createSeedState())
}), {
	name: "linha-atelier-v1",
	skipHydration: true,
	partialize: (s) => ({
		clients: s.clients,
		orders: s.orders,
		payments: s.payments
	})
}));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-DSHCkyC1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var NAV = [
	{
		to: "/",
		label: "Início",
		icon: House
	},
	{
		to: "/pedidos",
		label: "Pedidos",
		icon: ClipboardList
	},
	{
		to: "/producao",
		label: "Produção",
		icon: Scissors
	},
	{
		to: "/clientes",
		label: "Clientes",
		icon: Users
	},
	{
		to: "/financeiro",
		label: "Caixa",
		icon: Wallet
	}
];
function isActive(pathname, to) {
	if (to === "/") return pathname === "/";
	return pathname === to || pathname.startsWith(`${to}/`);
}
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				fill: "#2A4A62"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 20.5c3.2-6 5.4-9.2 8-9.2 2.4 0 3.2 2.6 4.2 2.6 1.4 0 2.6-2.4 4.8-6.4",
				fill: "none",
				stroke: "#F3EFE8",
				strokeWidth: "1.8",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22.5",
				cy: "9.2",
				r: "1.35",
				fill: "#F3EFE8"
			})
		]
	});
}
function Shell({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		const unsub = useWorkshop.persist.onFinishHydration(() => setReady(true));
		useWorkshop.persist.rehydrate();
		if (useWorkshop.persist.hasHydrated()) setReady(true);
		const fallback = window.setTimeout(() => setReady(true), 400);
		return () => {
			unsub();
			window.clearTimeout(fallback);
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-12" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl italic text-ink",
				children: "Linha"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "stitch w-16" })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-20 hidden w-56 border-r border-line bg-surface md:flex md:flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5 px-5 py-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-none italic",
							children: "Linha"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-[11px] text-muted",
							children: "Confecção"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-0.5 px-3",
						children: NAV.map((item) => {
							const active = isActive(pathname, item.to);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors duration-150", active ? "bg-denim text-denim-fg" : "text-muted hover:bg-wash hover:text-ink"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									strokeWidth: 1.75
								}), item.label]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-5 py-4 text-[11px] text-subtle",
						children: "Dados ficam neste aparelho."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:pl-56",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto min-h-dvh w-full max-w-3xl pb-[5.5rem] md:max-w-5xl md:pb-10",
					children
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface/95 backdrop-blur-md md:hidden",
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-5",
					children: NAV.map((item) => {
						const active = isActive(pathname, item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium", active ? "text-denim" : "text-subtle"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.1 : 1.7
							}), item.label]
						}) }, item.to);
					})
				})
			})
		]
	});
}
function PageHead({ kicker, title, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-end justify-between gap-3 px-5 pb-4 pt-6 md:pt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[12px] font-medium uppercase tracking-[0.14em] text-muted",
				children: kicker
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-[2rem] leading-tight italic text-ink",
				children: title
			})]
		}), action]
	});
}
function EmptyState({ title, hint, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-5 rounded-xl bg-raised px-5 py-10 text-center shadow-[var(--shadow-card)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl italic",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-xs text-sm text-muted",
				children: hint
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex justify-center",
				children: action
			}) : null
		]
	});
}
var styles_default = "/assets/styles-Ccans37B.css";
var APP_NAME = "Linha";
var Route$8 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Gestão simples para confecções: clientes, pedidos, produção, prazos e recebimentos."
			},
			{
				name: "theme-color",
				content: "#f3efe8"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "min-h-dvh bg-bg text-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					position: "top-center",
					toastOptions: {
						className: "font-sans",
						style: {
							background: "#faf7f2",
							color: "#1b1d24",
							border: "1px solid #ddd4c6"
						}
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$7 = () => import("./routes-Bb3JJ3Bo.mjs");
var Route$7 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./clientes-FSKnYyYv.mjs");
var Route$6 = createFileRoute("/clientes")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./financeiro-CJA1WpKa.mjs");
var Route$5 = createFileRoute("/financeiro")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./pedidos-DXoeFVSi.mjs");
var Route$4 = createFileRoute("/pedidos")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./producao-BD4w2_b-.mjs");
var Route$3 = createFileRoute("/producao")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./clientes._id-DzidVPxt.mjs");
var Route$2 = createFileRoute("/clientes/$id")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./pedidos._id-Dmk7H4JT.mjs");
var Route$1 = createFileRoute("/pedidos/$id")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./pedidos.novo-DAwR8ALt.mjs");
var Route = createFileRoute("/pedidos/novo")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$7.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$8
});
var ClientesRoute = Route$6.update({
	id: "/clientes",
	path: "/clientes",
	getParentRoute: () => Route$8
});
var FinanceiroRoute = Route$5.update({
	id: "/financeiro",
	path: "/financeiro",
	getParentRoute: () => Route$8
});
var PedidosRoute = Route$4.update({
	id: "/pedidos",
	path: "/pedidos",
	getParentRoute: () => Route$8
});
var ProducaoRoute = Route$3.update({
	id: "/producao",
	path: "/producao",
	getParentRoute: () => Route$8
});
var ClientesIdRoute = Route$2.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => ClientesRoute
});
var PedidosIdRoute = Route$1.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => PedidosRoute
});
var PedidosNovoRoute = Route.update({
	id: "/novo",
	path: "/novo",
	getParentRoute: () => PedidosRoute
});
var ClientesRouteChildren = { ClientesIdRoute };
var ClientesRouteWithChildren = ClientesRoute._addFileChildren(ClientesRouteChildren);
var PedidosRouteChildren = {
	PedidosIdRoute,
	PedidosNovoRoute
};
var rootRouteChildren = {
	IndexRoute,
	ClientesRoute: ClientesRouteWithChildren,
	FinanceiroRoute,
	PedidosRoute: PedidosRoute._addFileChildren(PedidosRouteChildren),
	ProducaoRoute
};
var routeTree = Route$8._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { todayLabel as A, nextStage as C, prazoLabel as D, payStatus as E, useWorkshop as M, whatsappHref as N, remainingOf as O, whatsappOrderText as P, money as S, paidOf as T, greeting as _, LogoMark as a, itemCount as b, PAYMENT_METHODS as c, STAGE_HINT as d, STAGE_LABEL as f, formatDayLong as g, formatDay as h, EmptyState as i, uid as j, todayIso as k, SIZE_OPTIONS as l, cn as m, Route$1 as n, PageHead as o, clientById as p, Route$2 as r, METHOD_LABEL as s, router_exports as t, STAGES as u, isOpen as v, orderTotal as w, itemSummary as x, isOverdue as y };
