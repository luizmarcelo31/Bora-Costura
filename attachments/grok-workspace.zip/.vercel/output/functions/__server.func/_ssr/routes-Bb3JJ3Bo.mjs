import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { f as ArrowRight, r as TriangleAlert, s as Plus } from "../_libs/lucide-react.mjs";
import { A as todayLabel, M as useWorkshop, O as remainingOf, S as money, _ as greeting, a as LogoMark, f as STAGE_LABEL, m as cn, p as clientById, u as STAGES, v as isOpen, y as isOverdue } from "./router-DSHCkyC1.mjs";
import { n as Button } from "./ui-BC_-lu7f.mjs";
import { t as OrderCard } from "./order-card-BNtwp81-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bb3JJ3Bo.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const clients = useWorkshop((s) => s.clients);
	const orders = useWorkshop((s) => s.orders);
	const payments = useWorkshop((s) => s.payments);
	const resetDemo = useWorkshop((s) => s.resetDemo);
	const open = orders.filter((o) => isOpen(o.stage));
	const overdue = open.filter(isOverdue);
	const dueSoon = open.filter((o) => !isOverdue(o)).slice().sort((a, b) => a.dueDate.localeCompare(b.dueDate)).slice(0, 4);
	const toReceive = open.reduce((sum, o) => sum + remainingOf(o, payments), 0);
	const inProduction = open.filter((o) => o.stage !== "orcamento" && o.stage !== "pronto").length;
	const ready = open.filter((o) => o.stage === "pronto");
	const stageCounts = STAGES.map((stage) => ({
		stage,
		count: orders.filter((o) => o.stage === stage).length
	}));
	const maxCount = Math.max(1, ...stageCounts.map((s) => s.count));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between px-5 pt-6 md:pt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl italic leading-none",
						children: "Linha"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden text-[12px] font-medium uppercase tracking-[0.14em] text-muted md:block",
					children: "Painel"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/pedidos/novo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						className: "gap-1.5 pl-3 pr-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Novo pedido"]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "px-5 pt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm capitalize text-muted",
					children: todayLabel()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "font-display text-[2.35rem] leading-[1.05] italic text-ink",
					children: [greeting(), "."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-md text-sm text-muted",
					children: overdue.length > 0 ? `${overdue.length} pedido${overdue.length > 1 ? "s" : ""} atrasado${overdue.length > 1 ? "s" : ""} · ${money(toReceive)} a receber` : `${open.length} em andamento · ${money(toReceive)} a receber`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-5 grid grid-cols-2 gap-2.5 px-5 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "A receber",
					value: money(toReceive)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "Em produção",
					value: String(inProduction)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "Atrasados",
					value: String(overdue.length),
					alert: overdue.length > 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "Prontos",
					value: String(ready.length)
				})
			]
		}),
		overdue.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "Atrasados",
				to: "/pedidos",
				extra: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-brick" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2 px-5",
				children: overdue.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
					order,
					clientName: clientById(clients, order.clientId)?.name ?? "Cliente",
					payments
				}, order.id))
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "Prazos da semana",
				to: "/pedidos"
			}), dueSoon.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-5 text-sm text-muted",
				children: "Nenhum prazo próximo. Bom sinal."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2 px-5",
				children: dueSoon.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
					order,
					clientName: clientById(clients, order.clientId)?.name ?? "Cliente",
					payments
				}, order.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-7 px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "Linha de produção",
				to: "/producao",
				flush: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-raised p-4 shadow-[var(--shadow-card)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-10 items-end gap-1.5",
					children: stageCounts.filter((s) => s.stage !== "entregue").map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex min-w-0 flex-1 flex-col items-center gap-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("w-full rounded-sm", s.stage === "pronto" ? "bg-sage" : "bg-denim"),
							style: { height: `${Math.max(6, s.count / maxCount * 40)}px` }
						})
					}, s.stage))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex gap-1.5",
					children: stageCounts.filter((s) => s.stage !== "entregue").map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "min-w-0 flex-1 text-center text-[10px] text-muted",
						children: [STAGE_LABEL[s.stage].slice(0, 4), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block tabular-nums text-ink",
							children: s.count
						})]
					}, s.stage))
				})]
			})]
		}),
		ready.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "Prontos para entregar",
				to: "/producao"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2 px-5",
				children: ready.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
					order,
					clientName: clientById(clients, order.clientId)?.name ?? "Cliente",
					payments
				}, order.id))
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10 px-5 pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "stitch mb-4 block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => resetDemo(),
				className: "text-[12px] text-subtle underline-offset-2 hover:text-muted hover:underline",
				children: "Restaurar dados de exemplo"
			})]
		})
	] });
}
function Kpi({ label, value, alert }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-raised px-3.5 py-3 shadow-[var(--shadow-card)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.12em] text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-1 font-display text-2xl tabular-nums italic", alert ? "text-brick" : "text-ink"),
			children: value
		})]
	});
}
function SectionTitle({ title, to, extra, flush }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("mb-3 flex items-center justify-between", flush ? "" : "px-5"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold text-ink",
				children: title
			}), extra]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to,
			className: "flex items-center gap-0.5 text-[12px] font-medium text-denim",
			children: ["Ver", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
		})]
	});
}
//#endregion
export { Home as component };
