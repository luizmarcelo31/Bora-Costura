import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { f as STAGE_LABEL } from "./router-DSHCkyC1.mjs";
import { t as Badge } from "./ui-BC_-lu7f.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stage-badge-DYMbC0JW.js
var import_jsx_runtime = require_jsx_runtime();
var TONE = {
	orcamento: "neutral",
	aprovado: "denim",
	corte: "denim",
	costura: "amber",
	acabamento: "amber",
	pronto: "sage",
	entregue: "sage",
	cancelado: "brick"
};
function StageBadge({ stage }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: TONE[stage],
		children: STAGE_LABEL[stage]
	});
}
function PayBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: status === "pago" ? "sage" : status === "parcial" ? "amber" : "brick",
		children: status === "pago" ? "Pago" : status === "parcial" ? "Parcial" : "A receber"
	});
}
//#endregion
export { StageBadge as n, PayBadge as t };
