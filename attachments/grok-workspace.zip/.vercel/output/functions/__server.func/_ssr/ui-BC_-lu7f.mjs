import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { m as cn } from "./router-DSHCkyC1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-BC_-lu7f.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[transform,background-color,box-shadow,opacity] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:opacity-50 disabled:pointer-events-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-denim", {
	variants: {
		variant: {
			primary: "bg-denim text-denim-fg shadow-[0_1px_0_rgb(27_29_36/0.12)] hover:bg-denim/90",
			secondary: "bg-raised text-ink shadow-[0_0_0_1px_var(--color-line)] hover:bg-surface",
			ghost: "bg-transparent text-ink hover:bg-wash",
			danger: "bg-brick text-denim-fg hover:bg-brick/90",
			sage: "bg-sage text-denim-fg hover:bg-sage/90"
		},
		size: {
			md: "h-11 px-4",
			sm: "h-9 px-3 text-[13px]",
			lg: "h-12 px-5",
			icon: "size-11 p-0"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var fieldClass = "h-11 w-full rounded-md border-0 bg-raised px-3 text-sm text-ink shadow-[0_0_0_1px_var(--color-line)] placeholder:text-subtle outline-none transition-[box-shadow] duration-150 focus:shadow-[0_0_0_2px_var(--color-denim)]";
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn(fieldClass, className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn(fieldClass, "h-24 min-h-20 resize-y py-2.5", className),
		...props
	});
}
function Select({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn(fieldClass, "pr-8", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-1.5 block text-[13px] font-medium text-muted", className),
		...props
	});
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function Badge({ children, tone = "neutral", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold tracking-wide", {
			neutral: "bg-wash text-ink",
			denim: "bg-denim/10 text-denim",
			sage: "bg-sage/10 text-sage",
			amber: "bg-amber/12 text-amber",
			brick: "bg-brick/10 text-brick"
		}[tone], className),
		children
	});
}
//#endregion
export { Select as a, Input as i, Button as n, Textarea as o, Field as r, Badge as t };
