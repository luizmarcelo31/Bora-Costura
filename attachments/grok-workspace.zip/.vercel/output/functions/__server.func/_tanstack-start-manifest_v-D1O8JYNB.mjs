//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D1O8JYNB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/clientes",
			"/financeiro",
			"/pedidos",
			"/producao"
		],
		preloads: [
			"/assets/index-Bslbdfu5.js",
			"/assets/store-B8g97Xk3.js",
			"/assets/preload-helper-rrCl1Iy5.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bslbdfu5.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cjd4g2sc.js",
			"/assets/plus-CecdG2xV.js",
			"/assets/ui-BVnFS1qc.js",
			"/assets/order-card-DLk49ZBf.js"
		]
	},
	"/clientes": {
		filePath: "/workspace/src/routes/clientes.tsx",
		children: ["/clientes/$id"],
		preloads: [
			"/assets/clientes-Ckm6eQUu.js",
			"/assets/chevron-right-1G-jo8_o.js",
			"/assets/plus-CecdG2xV.js",
			"/assets/search-DZHFFUtr.js",
			"/assets/drawers-wa4e8eUA.js",
			"/assets/ui-BVnFS1qc.js"
		]
	},
	"/financeiro": {
		filePath: "/workspace/src/routes/financeiro.tsx",
		children: void 0,
		preloads: [
			"/assets/financeiro-DfuhwqpO.js",
			"/assets/drawers-wa4e8eUA.js",
			"/assets/ui-BVnFS1qc.js",
			"/assets/stage-badge-G9EWD-A6.js"
		]
	},
	"/pedidos": {
		filePath: "/workspace/src/routes/pedidos.tsx",
		children: ["/pedidos/$id", "/pedidos/novo"],
		preloads: [
			"/assets/pedidos-BugbNw-c.js",
			"/assets/plus-CecdG2xV.js",
			"/assets/search-DZHFFUtr.js",
			"/assets/ui-BVnFS1qc.js",
			"/assets/order-card-DLk49ZBf.js"
		]
	},
	"/producao": {
		filePath: "/workspace/src/routes/producao.tsx",
		children: void 0,
		preloads: ["/assets/producao-DnZReJhG.js", "/assets/ui-BVnFS1qc.js"]
	},
	"/clientes/$id": {
		filePath: "/workspace/src/routes/clientes.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/clientes._id-ks1Gf2BQ.js",
			"/assets/useNavigate-DAIufo61.js",
			"/assets/message-circle-Cq_mnMF1.js",
			"/assets/order-card-DLk49ZBf.js"
		]
	},
	"/pedidos/$id": {
		filePath: "/workspace/src/routes/pedidos.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/pedidos._id-DeGYS7aS.js",
			"/assets/useNavigate-DAIufo61.js",
			"/assets/message-circle-Cq_mnMF1.js",
			"/assets/trash-2-DHiKysKp.js",
			"/assets/drawers-wa4e8eUA.js",
			"/assets/stage-badge-G9EWD-A6.js"
		]
	},
	"/pedidos/novo": {
		filePath: "/workspace/src/routes/pedidos.novo.tsx",
		children: void 0,
		preloads: [
			"/assets/pedidos.novo-6jXMj2sP.js",
			"/assets/useNavigate-DAIufo61.js",
			"/assets/trash-2-DHiKysKp.js",
			"/assets/drawers-wa4e8eUA.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
