import { create } from "zustand";
import { persist } from "zustand/middleware";
import { todayIso } from "@/lib/format";
import { createSeedState } from "@/lib/seed";
import type { Client, Order, Payment, ProductionStage, WorkshopState } from "@/lib/types";
import { nextNumber, nextStage } from "@/lib/workshop";
import { uid } from "@/lib/utils";

type Actions = {
  addClient: (input: Omit<Client, "id" | "createdAt">) => string;
  updateClient: (id: string, patch: Partial<Omit<Client, "id">>) => void;
  deleteClient: (id: string) => boolean;
  addOrder: (input: Omit<Order, "id" | "number" | "createdAt">) => string;
  updateOrder: (id: string, patch: Partial<Omit<Order, "id" | "number">>) => void;
  deleteOrder: (id: string) => void;
  setStage: (id: string, stage: ProductionStage) => void;
  advance: (id: string) => ProductionStage | null;
  addPayment: (input: Omit<Payment, "id">) => void;
  deletePayment: (id: string) => void;
  resetDemo: () => void;
};

type Store = WorkshopState & Actions;

export const useWorkshop = create<Store>()(
  persist(
    (set, get) => ({
      ...createSeedState(),
      addClient: (input) => {
        const id = uid("c");
        const client: Client = { ...input, id, createdAt: todayIso() };
        set({ clients: [...get().clients, client] });
        return id;
      },
      updateClient: (id, patch) => {
        set({
          clients: get().clients.map((c) => (c.id === id ? { ...c, ...patch } : c)),
        });
      },
      deleteClient: (id) => {
        const hasOrders = get().orders.some((o) => o.clientId === id);
        if (hasOrders) return false;
        set({ clients: get().clients.filter((c) => c.id !== id) });
        return true;
      },
      addOrder: (input) => {
        const id = uid("o");
        const order: Order = {
          ...input,
          id,
          number: nextNumber(get().orders),
          createdAt: todayIso(),
        };
        set({ orders: [order, ...get().orders] });
        return id;
      },
      updateOrder: (id, patch) => {
        set({
          orders: get().orders.map((o) => (o.id === id ? { ...o, ...patch } : o)),
        });
      },
      deleteOrder: (id) => {
        set({
          orders: get().orders.filter((o) => o.id !== id),
          payments: get().payments.filter((p) => p.orderId !== id),
        });
      },
      setStage: (id, stage) => {
        set({
          orders: get().orders.map((o) => {
            if (o.id !== id) return o;
            const deliveredAt =
              stage === "entregue" ? (o.deliveredAt ?? todayIso()) : stage === "cancelado" ? o.deliveredAt : null;
            return { ...o, stage, deliveredAt };
          }),
        });
      },
      advance: (id) => {
        const order = get().orders.find((o) => o.id === id);
        if (!order) return null;
        const nxt = nextStage(order.stage);
        if (!nxt) return null;
        get().setStage(id, nxt);
        return nxt;
      },
      addPayment: (input) => {
        const payment: Payment = { ...input, id: uid("p") };
        set({ payments: [...get().payments, payment] });
      },
      deletePayment: (id) => {
        set({ payments: get().payments.filter((p) => p.id !== id) });
      },
      resetDemo: () => set(createSeedState()),
    }),
    {
      name: "linha-atelier-v1",
      partialize: (s) => ({
        clients: s.clients,
        orders: s.orders,
        payments: s.payments,
      }),
    },
  ),
);
